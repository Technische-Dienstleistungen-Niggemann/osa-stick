# Parts list
These are the parts intended for this PCB: 

1 x Electrolytic Capacitor 47uF 16V (C1)  
1 x Ceramic Capacitor 10nF 50V (C2)  
2 x Resistor 1k Ohm 0,125w (R1+R2)  
1 x 555 IC NE555P
1 x Potentiometer 5k Ohm

If you want a wider range for the firing rate, you can, for example, use a 470 Ohm resistor as R2 and a 10k Ohm potentiometer.


![CC BY NC SA 4.0](/images/cc-by-nc-sa-icon-border-200x72.png "CC BY NC SA 4.0")